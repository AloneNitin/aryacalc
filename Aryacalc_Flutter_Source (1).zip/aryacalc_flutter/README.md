# Aryacalc — Flutter app source

A cross-platform Flutter starter app for Android and iOS with:
- Age calculator
- BMI calculator
- Currency converter (fetches indicative rates from open.er-api.com; internet required)
- Length, weight and temperature converter
- EMI / loan calculator
- Percentage calculator
- Date difference calculator
- Search, categories, responsive card dashboard

## Requirements
- Flutter SDK (stable)
- Android Studio and/or Xcode (Xcode is required to build/sign iOS apps and is available on macOS)
- Internet connection for currency exchange rates

## Run locally
1. Install Flutter and verify it: `flutter doctor`
2. Unzip this project.
3. In the project folder run:
   ```bash
   flutter create . --platforms=android,ios
   flutter pub get
   flutter run
   ```
   If `flutter create` asks to overwrite files, keep the existing `lib/main.dart`, `pubspec.yaml`, and Android manifest.
4. Choose an Android emulator/phone or iOS simulator.

## Build
- Android APK: `flutter build apk --release`
- Android app bundle (Play Store): `flutter build appbundle --release`
- iOS: `flutter build ios --release` (requires macOS + Xcode; signing configured in Xcode)

## Notes
- Currency rates are online indicative rates, not guaranteed bank/card settlement rates.
- BMI is a screening estimate, not a medical diagnosis.
- Loan outputs use a standard fixed-rate monthly amortization formula. Currency symbol in loan output is currently ₹; change it in `lib/main.dart` if you want another local currency.
- This is source code, not a prebuilt APK/IPA. App store publishing requires developer accounts, signing, store assets and review.
