import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const AryacalcApp());

const brand = Color(0xFF2563EB);
const ink = Color(0xFF172033);

class AryacalcApp extends StatelessWidget {
  const AryacalcApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Aryacalc',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: brand),
      scaffoldBackgroundColor: const Color(0xFFF5F8FF),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFE1E8F0))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Color(0xFFE1E8F0))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: brand, width: 1.5)),
      ),
    ),
    home: const HomePage(),
  );
}

class CalcInfo {
  final String title, subtitle, icon, category;
  const CalcInfo(this.title, this.subtitle, this.icon, this.category);
}
const calculators = <CalcInfo>[
  CalcInfo('Age Calculator', 'Your exact age in years, months and days', '🎂', 'Personal'),
  CalcInfo('BMI Calculator', 'Check your body mass index', '⚖️', 'Personal'),
  CalcInfo('Currency Converter', 'Convert currencies using live rates', '💱', 'Conversion'),
  CalcInfo('Unit Converter', 'Length, weight and temperature', '📏', 'Conversion'),
  CalcInfo('EMI Calculator', 'Estimate your monthly instalment', '🏠', 'Finance'),
  CalcInfo('Loan Calculator', 'See total interest and repayment', '💰', 'Finance'),
  CalcInfo('Percentage Calculator', 'Calculate percentages quickly', '％', 'Math'),
  CalcInfo('Date Calculator', 'Find the days between two dates', '📅', 'Date & Time'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String query = '';
  String category = 'All';
  int tab = 0;
  final categories = const ['All', 'Personal', 'Finance', 'Conversion', 'Math', 'Date & Time'];
  @override
  Widget build(BuildContext context) {
    final filtered = calculators.where((c) =>
      (category == 'All' || c.category == category) &&
      ('${c.title} ${c.subtitle} ${c.category}'.toLowerCase().contains(query.toLowerCase()))).toList();
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [Container(width: 35,height: 35,decoration: BoxDecoration(color: brand,borderRadius: BorderRadius.circular(11)),child: const Icon(Icons.calculate_rounded,color: Colors.white)), const SizedBox(width: 10), const Text('Arya',style: TextStyle(fontWeight: FontWeight.w800,color: brand)), const Text('calc',style: TextStyle(fontWeight: FontWeight.w800,color: ink))]),
        actions: [IconButton(tooltip: 'About Aryacalc', onPressed: () => showAboutDialog(context: context, applicationName: 'Aryacalc', applicationVersion: '1.0.0', children: const [Text('Smart Calculators. Simple Solutions.')]), icon: const Icon(Icons.info_outline))],
      ),
      body: tab == 0 ? _home(filtered) : _all(filtered),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v)=>setState(()=>tab=v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'All tools'),
      ]),
    );
  }
  Widget _home(List<CalcInfo> filtered) => ListView(padding: const EdgeInsets.fromLTRB(18,18,18,28), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors:[Color(0xFF2563EB),Color(0xFF1E40AF)]),borderRadius: BorderRadius.circular(23)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('SMART CALCULATORS',style: TextStyle(color: Color(0xFFDCE8FF),fontWeight: FontWeight.w700,letterSpacing: 1.3,fontSize: 11)),
      SizedBox(height: 10), Text('Calculate anything.',style: TextStyle(color: Colors.white,fontSize: 27,fontWeight: FontWeight.w800)),
      Text('Simple solutions, right at your fingertips.',style: TextStyle(color: Colors.white70,fontSize: 14)),
    ])),
    const SizedBox(height: 18),
    const BasicCalculator(),
    const SizedBox(height: 20),
    TextField(decoration: const InputDecoration(hintText: 'Search calculators...',prefixIcon: Icon(Icons.search),contentPadding: EdgeInsets.symmetric(vertical: 13)),onChanged:(v)=>setState(()=>query=v)),
    const SizedBox(height: 18),
    const Text('Popular calculators',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w800,color: ink)),
    const SizedBox(height: 12),
    _grid(filtered.take(4).toList()),
    const SizedBox(height: 22),
    const Text('Explore all tools',style: TextStyle(fontSize: 19,fontWeight: FontWeight.w800,color: ink)),
    const SizedBox(height: 12),
    _categoryChips(),
    const SizedBox(height: 12),
    _grid(filtered),
    const SizedBox(height: 14),
    const Center(child: Text('Aryacalc • Calculate Anything, Anytime',style: TextStyle(color: Colors.blueGrey,fontSize: 12))),
  ]);
  Widget _all(List<CalcInfo> filtered) => ListView(padding: const EdgeInsets.all(18),children:[
    const Text('All calculators',style: TextStyle(fontSize: 25,fontWeight: FontWeight.w800)),
    const SizedBox(height: 14),
    TextField(decoration: const InputDecoration(hintText:'Find a calculator',prefixIcon:Icon(Icons.search)),onChanged:(v)=>setState(()=>query=v)),
    const SizedBox(height: 12), _categoryChips(), const SizedBox(height: 12), _grid(filtered),
  ]);
  Widget _categoryChips()=>SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:categories.map((c)=>Padding(padding:const EdgeInsets.only(right:7),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c)))).toList()));
  Widget _grid(List<CalcInfo> items)=>GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:items.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:11,mainAxisSpacing:11,childAspectRatio:1.13),itemBuilder:(context,i){
    final c=items[i]; return Material(color:Colors.white,borderRadius:BorderRadius.circular(17),child:InkWell(borderRadius:BorderRadius.circular(17),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CalculatorPage(info:c))),child:Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(border:Border.all(color:const Color(0xFFE6ECF4)),borderRadius:BorderRadius.circular(17)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(c.icon,style:const TextStyle(fontSize:25)),const Spacer(),Text(c.title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:14)),const SizedBox(height:3),Text(c.subtitle,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.blueGrey,fontSize:11,height:1.3)),
    ]))));
  });
}


class BasicCalculator extends StatefulWidget {
  const BasicCalculator({super.key});
  @override State<BasicCalculator> createState() => _BasicCalculatorState();
}

class _BasicCalculatorState extends State<BasicCalculator> {
  String display = '0';
  double? stored;
  String? operation;
  bool fresh = true;

  void press(String key) {
    setState(() {
      if (key == 'AC') {
        display = '0'; stored = null; operation = null; fresh = true;
      } else if (key == '⌫') {
        if (!fresh && display.length > 1) {
          display = display.substring(0, display.length - 1);
        } else { display = '0'; }
      } else if (key == '%') {
        final v = (double.tryParse(display) ?? 0) / 100;
        display = _format(v); fresh = true;
      } else if (['+', '−', '×', '÷'].contains(key)) {
        stored = double.tryParse(display) ?? 0;
        operation = key; fresh = true;
      } else if (key == '=') {
        if (stored != null && operation != null) {
          final a = stored!, b = double.tryParse(display) ?? 0;
          double answer;
          switch (operation) {
            case '+': answer = a + b; break;
            case '−': answer = a - b; break;
            case '×': answer = a * b; break;
            case '÷': answer = b == 0 ? double.nan : a / b; break;
            default: answer = b;
          }
          display = answer.isNaN ? 'Cannot divide by zero' : _format(answer);
          stored = null; operation = null; fresh = true;
        }
      } else if (key == '.') {
        if (fresh) { display = '0.'; fresh = false; }
        else if (!display.contains('.')) { display += '.'; }
      } else {
        if (fresh || display == '0' || display == 'Cannot divide by zero') {
          display = key; fresh = false;
        } else if (display.length < 16) { display += key; }
      }
    });
  }

  String _format(double value) {
    if (!value.isFinite) return 'Error';
    if (value.abs() >= 1e14) return value.toStringAsExponential(6);
    return value == value.roundToDouble() ? value.toInt().toString() : value.toStringAsPrecision(10).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }

  @override Widget build(BuildContext context) {
    const keys = [
      ['AC', '⌫', '%', '÷'],
      ['7', '8', '9', '×'],
      ['4', '5', '6', '−'],
      ['1', '2', '3', '+'],
      ['0', '.', '='],
    ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE1E8F0)), boxShadow: const [BoxShadow(color: Color(0x0A172033), blurRadius: 12, offset: Offset(0, 4))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.calculate_rounded, color: brand), SizedBox(width: 8), Text('Basic Calculator', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: ink))]),
        const SizedBox(height: 12),
        Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18), decoration: BoxDecoration(color: const Color(0xFFF3F6FC), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(operation == null ? ' ' : ' ${stored == null ? '' : _format(stored!)} $operation', style: const TextStyle(color: Colors.blueGrey, fontSize: 13)),
          const SizedBox(height: 5),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(display, maxLines: 1, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: ink))),
        ])),
        const SizedBox(height: 12),
        ...keys.map((row) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: row.map((key) {
          final isOperator = ['÷', '×', '−', '+', '='].contains(key);
          final isAction = ['AC', '⌫', '%'].contains(key);
          return Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: SizedBox(height: 52, child: FilledButton(
            onPressed: () => press(key),
            style: FilledButton.styleFrom(backgroundColor: isOperator ? brand : isAction ? const Color(0xFFE8EEFA) : const Color(0xFFF3F6FC), foregroundColor: isOperator ? Colors.white : ink, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
            child: Text(key, style: TextStyle(fontSize: key == 'AC' ? 15 : 19, fontWeight: FontWeight.w700)),
          )));
        }).toList()))),
      ]),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  final CalcInfo info;
  const CalculatorPage({super.key,required this.info});
  @override State<CalculatorPage> createState()=>_CalculatorPageState();
}
class _CalculatorPageState extends State<CalculatorPage>{
  final Map<String,TextEditingController> c={};
  String result='', detail='';
  String from='USD',to='INR',unitType='Length',unitFrom='Meter',unitTo='Kilometer';
  bool loading=false;
  final currencies=['USD','INR','EUR','GBP','CAD','AUD','JPY','AED','CNY','SGD'];
  TextEditingController ctl(String key,[String initial=''])=>c.putIfAbsent(key,()=>TextEditingController(text:initial));
  double n(String key)=>double.tryParse(ctl(key).text.trim())??0;
  void showResult(String r,[String d=''])=>setState(() { result=r; detail=d; });
  @override void dispose(){for(final x in c.values){x.dispose();}super.dispose();}
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:Text(widget.info.title,style:const TextStyle(fontWeight:FontWeight.w800))),body:ListView(padding:const EdgeInsets.all(18),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFFEAF1FF),borderRadius:BorderRadius.circular(17)),child:Row(children:[Text(widget.info.icon,style:const TextStyle(fontSize:32)),const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.info.title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),Text(widget.info.subtitle,style:const TextStyle(color:Colors.blueGrey,fontSize:12))]))])),
      const SizedBox(height:18),
      _form(),
      const SizedBox(height:16),
      if(result.isNotEmpty) Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFFE8F7F1),borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0xFFB7E7D1))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('RESULT',style:TextStyle(color:Color(0xFF047857),fontWeight:FontWeight.w800,fontSize:11,letterSpacing:1)),const SizedBox(height:6),Text(result,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800,color:Color(0xFF065F46))),if(detail.isNotEmpty)Padding(padding:const EdgeInsets.only(top:5),child:Text(detail,style:const TextStyle(color:Color(0xFF16634E))))])),
      const SizedBox(height:18),const Text('Aryacalc results are estimates. Check important financial or health decisions with a qualified professional.',style:TextStyle(color:Colors.blueGrey,fontSize:11)),
    ]));
  }
  Widget field(String label,String key,{String hint='',String initial='',TextInputType type=TextInputType.number})=>Padding(padding:const EdgeInsets.only(bottom:13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),const SizedBox(height:6),TextField(controller:ctl(key,initial),keyboardType:type,decoration:InputDecoration(hintText:hint))]));
  Widget dropdown(String label,String value,List<String> options,ValueChanged<String?> change)=>Padding(padding:const EdgeInsets.only(bottom:13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),const SizedBox(height:6),DropdownButtonFormField<String>(value:value,items:options.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:change)]));
  Widget button(String label,VoidCallback action)=>SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:action,icon:const Icon(Icons.calculate),label:Text(label),style:FilledButton.styleFrom(backgroundColor:brand,padding:const EdgeInsets.symmetric(vertical:14),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(13)))));
  Widget _form(){
    switch(widget.info.title){
      case 'Age Calculator': return Column(children:[field('Date of birth (YYYY-MM-DD)','dob',hint:'e.g. 1995-08-21',type:TextInputType.datetime),button('Calculate age',(){try{final d=DateTime.parse(ctl('dob').text);final now=DateTime.now();if(d.isAfter(now))throw Exception();int y=now.year-d.year,m=now.month-d.month,days=now.day-d.day;if(days<0){m--;days+=DateTime(now.year,now.month,0).day;}if(m<0){y--;m+=12;}showResult('$y years, $m months, $days days');}catch(_){showResult('Please enter a valid past date','Use YYYY-MM-DD format.');}})]);
      case 'BMI Calculator': return Column(children:[field('Weight (kg)','weight',hint:'e.g. 68'),field('Height (cm)','height',hint:'e.g. 172'),button('Calculate BMI',(){final h=n('height')/100;if(n('weight')<=0||h<=0){showResult('Enter valid weight and height');return;}final bmi=n('weight')/(h*h);final label=bmi<18.5?'Underweight':bmi<25?'Normal range':bmi<30?'Overweight':'Obesity range';showResult('${bmi.toStringAsFixed(1)} — $label','Adult BMI categories are a general screening guide, not a diagnosis.');})]);
      case 'Currency Converter': return Column(children:[field('Amount','amount',initial:'1'),dropdown('From',from,currencies,(v)=>setState(()=>from=v!)),dropdown('To',to,currencies,(v)=>setState(()=>to=v!)),button(loading?'Getting rate...':'Convert using live rate',_currency)]);
      case 'Unit Converter': return Column(children:[field('Value','value',initial:'1'),dropdown('Category',unitType,['Length','Weight','Temperature'],(v)=>setState(() { unitType=v!; unitFrom=unitType=='Length'?'Meter':unitType=='Weight'?'Kilogram':'Celsius'; unitTo=unitType=='Length'?'Kilometer':unitType=='Weight'?'Gram':'Fahrenheit'; })),dropdown('From',unitFrom,_units(),(v)=>setState(()=>unitFrom=v!)),dropdown('To',unitTo,_units(),(v)=>setState(()=>unitTo=v!)),button('Convert',_unit)]);
      case 'EMI Calculator': case 'Loan Calculator': return Column(children:[field('Loan amount','principal',hint:'e.g. 2500000'),field('Annual interest rate (%)','rate',hint:'e.g. 8.5'),field('Loan tenure (years)','years',hint:'e.g. 20'),button('Calculate loan',_loan)]);
      case 'Percentage Calculator': return Column(children:[field('What is the percentage?','percent',initial:'15'),field('Of which number?','whole',initial:'200'),button('Calculate percentage',(){final v=n('percent')*n('whole')/100;showResult(v.toStringAsFixed(2),'${n('percent')}% of ${n('whole')}');})]);
      case 'Date Calculator': return Column(children:[field('Start date (YYYY-MM-DD)','start',hint:'e.g. 2026-01-01',type:TextInputType.datetime),field('End date (YYYY-MM-DD)','end',hint:'e.g. 2026-12-31',type:TextInputType.datetime),button('Calculate date difference',(){try{final a=DateTime.parse(ctl('start').text),b=DateTime.parse(ctl('end').text);final days=b.difference(a).inDays.abs();showResult('$days days','${(days/7).floor()} weeks and ${days%7} days');}catch(_){showResult('Please enter both dates','Use YYYY-MM-DD format.');}})]);
      default:return const SizedBox.shrink();
    }
  }
  List<String> _units()=>unitType=='Length'?['Meter','Kilometer','Centimeter','Millimeter','Mile','Foot','Inch']:unitType=='Weight'?['Kilogram','Gram','Milligram','Pound','Ounce']:['Celsius','Fahrenheit','Kelvin'];
  void _unit(){
    final x=n('value');double v=x;
    if(unitType=='Length'){
      const f={'Meter':1.0,'Kilometer':1000.0,'Centimeter':.01,'Millimeter':.001,'Mile':1609.344,'Foot':.3048,'Inch':.0254};v=x*f[unitFrom]!/f[unitTo]!;
    }else if(unitType=='Weight'){
      const f={'Kilogram':1.0,'Gram':.001,'Milligram':.000001,'Pound':.45359237,'Ounce':.028349523125};v=x*f[unitFrom]!/f[unitTo]!;
    }else{
      double celsius=unitFrom=='Celsius'?x:unitFrom=='Fahrenheit'?(x-32)*5/9:x-273.15;
      v=unitTo=='Celsius'?celsius:unitTo=='Fahrenheit'?celsius*9/5+32:celsius+273.15;
    }
    showResult('${v.toStringAsFixed(6).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '')} $unitTo','$x $unitFrom converted to $unitTo');
  }
  Future<void> _currency() async{
    if(n('amount')<=0){showResult('Enter an amount greater than zero');return;}
    setState(()=>loading=true);
    try{
      final response=await http.get(Uri.parse('https://open.er-api.com/v6/latest/$from')).timeout(const Duration(seconds:12));
      if(response.statusCode!=200)throw Exception('Rate service unavailable');
      final data=jsonDecode(response.body) as Map<String,dynamic>;
      if(data['result']!='success')throw Exception('Could not retrieve exchange rates');
      final rates=data['rates'] as Map<String,dynamic>;
      final rate=(rates[to] as num).toDouble();final converted=n('amount')*rate;
      showResult('$to ${converted.toStringAsFixed(2)}','Rate: 1 $from = ${rate.toStringAsFixed(5)} $to • Rates are indicative and may change.');
    }catch(e){showResult('Could not load exchange rate','Check your internet connection and try again.');}
    finally{if(mounted)setState(()=>loading=false);}
  }
  void _loan(){
    final p=n('principal'),annual=n('rate'),years=n('years');
    if(p<=0||annual<0||years<=0){showResult('Enter a valid amount, rate and tenure');return;}
    final months=(years*12).round();final r=annual/1200;
    final emi=r==0?p/months:p*r*(pow1(r,months))/(pow1(r,months)-1);
    final total=emi*months,interest=total-p;
    showResult('₹ ${emi.toStringAsFixed(2)} / month','Total payment: ₹ ${total.toStringAsFixed(2)}\nTotal interest: ₹ ${interest.toStringAsFixed(2)}\nTenure: $months months');
  }
  double pow1(double x,int n){double v=1;for(int i=0;i<n;i++){v*=1+x;}return v;}
}
